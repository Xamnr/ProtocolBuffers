import formobilechat_pb2 as formobilechat_pb2

FormobileChat = formobilechat_pb2.FormobileChat()

FormobileChat.chat_thread_id = 1
FormobileChat.chat_contact = "Karl Agathon"
FormobileChat.chat_text = "Patrick sorry you could not make it tonight to get your cut of the cash.  We will use you for the next bank.  Got something for you"
FormobileChat.chat_attachment = bytes([0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46, 0x49, 0x46, 0x00, 0x01, 0x01, 0x01,0xFF, 0xD9])
FormobileChat.chat_latitude = 5.50559
FormobileChat.chat_longitude =  -0.08956
FormobileChat.chat_timestamp=  1616182435
FormobileChat.chat_direction = 1
FormobileChat.chat_status = 2

print(FormobileChat)

with open("FormobileChatsmall.bin", "wb") as f:
    bytesAsString = FormobileChat.SerializeToString()
    f.write(bytesAsString)
